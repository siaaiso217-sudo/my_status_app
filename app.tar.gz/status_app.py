import flet as ft
import firebase_admin
from firebase_admin import credentials, db
import datetime

# Web公開時は、サーバー用の秘密鍵(json)ではなく、
# Firebaseコンソールで取得した「databaseURL」を直接指定して初期化します。
# ※注意：GitHub Pagesなどでは「秘密鍵なし」で匿名アクセスを許可する設定が必要です。

if not firebase_admin._apps:
    # 秘密鍵を使わず、URLだけで初期化（ルールが .read: true, .write: true の場合）
    firebase_admin.initialize_app(options={
        'databaseURL': 'https://status-app-e6835-default-rtdb.asia-southeast1.firebasedatabase.app/'
    })

ref = db.reference('my_status')

def main(page: ft.Page):
    page.title = "ステータス共有"
    page.theme_mode = ft.ThemeMode.LIGHT
    #ページの中身を縦に中央寄せ
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    #ページの中身を横に中央寄せ
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.bgcolor = ft.Colors.BLUE_GREY_50
    page.padding = 30

    # 1. 状態を表示するアイコンとテキスト
    #ステータスを表すアイコンを作成
    status_icon = ft.Icon(ft.Icons.HOME_ROUNDED, size=80, color=ft.Colors.BLUE_400)
    #ステータスを文字で表示するためのテキスト
    status_text = ft.Text("在宅中", size=28, weight=ft.FontWeight.BOLD, color=ft.Colors.BLACK87)

    #ステータスについてアイコンとテキストを縦に並べて表示エリアとしてまとめる
    status_display = ft.Container(
        content=ft.Column(
            controls=[status_icon, status_text], #アイコンとテキストを縦並べ
            horizontal_alignment=ft.CrossAxisAlignment.CENTER, #横方向中央揃え
            spacing=10,
        ),
        margin=ft.margin.only(bottom=30),
    )

    # 2. ボタンを押した時の「動き」
    def on_click(e): #eはイベント情報が入ったオブジェクト

        #ここでステータステキストを変更
        val = e.control.data #e.control(ボタン)に設定しておいたdataを取り出す
        status_text.value = val #ステータス表示用のテキストをボタン対応に変更

        try:
            # Firebaseにデータを送信
            ref.set({
                'status': val,
                'updated_at': datetime.datetime.now().strftime("%Y/%m/%d %H:%M:%S")
            })
            print("✅ Firebaseへの書き込みに成功しました！") # 証拠2
        except Exception as err:
            print(f"❌ 書き込みエラーが発生しました: {err}") # エラーならこれが出る

        #ここでステータスアイコンを変更
        if val == "在宅中":
            status_icon.icon = ft.Icons.HOME_ROUNDED
            status_icon.color = ft.Colors.BLUE_400
        elif val == "外出中":
            status_icon.icon = ft.Icons.DIRECTIONS_RUN_ROUNDED # type: ignore
            status_icon.color = ft.Colors.GREEN_400
        elif val == "予定あり":
            status_icon.icon = ft.Icons.DO_NOT_DISTURB_ON_TOTAL_SILENCE_ROUNDED # type: ignore
            status_icon.color = ft.Colors.RED_400

        page.update() #再描画

    # 3.Firebaseのデータが変わった時に呼ばれる「お留守番」関数
    def on_status_change(event):
            # 届いたデータの中身を確認（デバッグ用）
            print(f"信号受信: {event.data}")

            # event.data が辞書型なら .get() を使い、文字列ならそのまま使う
            if isinstance(event.data, dict):
                new_status = event.data.get('status', "在宅中")
            else:
                # 1つの値（文字列）だけが届いた場合
                new_status = event.data

            # Noneや予期しない値が来た場合の安全策
            if new_status is None or not isinstance(new_status, str):
                return

            # 画面の文字とアイコンを更新
            status_text.value = new_status

            if new_status == "在宅中":
                status_icon.icon = ft.Icons.HOME_ROUNDED
                status_icon.color = ft.Colors.BLUE_400
            elif new_status == "外出中":
                status_icon.icon = ft.Icons.DIRECTIONS_RUN_ROUNDED
                status_icon.color = ft.Colors.GREEN_400
            elif new_status == "予定あり":
                status_icon.icon = ft.Icons.DO_NOT_DISTURB_ON_TOTAL_SILENCE_ROUNDED
                status_icon.color = ft.Colors.RED_400

            page.update()

    # Firebaseに「見守り」を開始させる命令
    ref.listen(on_status_change)

    # 4. ボタンの共通設定
    def create_status_button(label, icon_name):#label;文字 icon_name;アイコン種類
        return ft.OutlinedButton(
            content=ft.Row( #横並びコンテナ
                [ft.Icon(icon_name), ft.Text(label)],
                alignment=ft.MainAxisAlignment.CENTER,
                tight=True,
            ),
            data=label, # ここに状態名を隠し持たせる
            on_click=on_click,
            width=250,
            style=ft.ButtonStyle( #見た目
                shape=ft.RoundedRectangleBorder(radius=10),
                padding=ft.padding.all(20),
            ),
        )

    # 5. メインコンテンツ
    main_card = ft.Container(
        content=ft.Column(
            controls=[
                status_display,
                ft.Column(
                    controls=[
                        create_status_button("在宅中", ft.Icons.HOME_ROUNDED),
                        create_status_button("外出中", ft.Icons.DIRECTIONS_RUN_ROUNDED),
                        create_status_button("取り込み中", ft.Icons.DO_NOT_DISTURB_ON_TOTAL_SILENCE_ROUNDED),
                    ],
                    spacing=15,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                ),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        bgcolor=ft.Colors.WHITE,
        padding=40,
        border_radius=20,
        width=350,
    )

    page.add(main_card)

# 修正前: ft.app(target=main)
# 修正後: Webブラウザモードで起動し、ネットワーク上の他デバイスからも見えるようにする
ft.app(target=main, view=ft.AppView.WEB_BROWSER, port=8550, host="0.0.0.0")